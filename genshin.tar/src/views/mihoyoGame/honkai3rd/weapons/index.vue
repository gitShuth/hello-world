<template>
  <div>
    <h1>崩坏三--Honkai3rd-Weapons</h1>
  </div>
</template>

<script setup lang="ts"></script>

<style scoped></style>
