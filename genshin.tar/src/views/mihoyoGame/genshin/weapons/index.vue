<template>
  <div>
    <h1>Genshin-Weapons--武器</h1>
  </div>
</template>

<script setup lang="ts"></script>

<style scoped></style>
