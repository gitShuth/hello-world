<template>
  <div>
    <h1>Genshin-Role--角色</h1>
  </div>
</template>

<script setup lang="ts"></script>

<style scoped></style>
