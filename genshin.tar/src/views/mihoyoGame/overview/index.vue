<template>
  <div>数据总览</div>
</template>

<script setup lang="ts"></script>

<style scoped></style>
